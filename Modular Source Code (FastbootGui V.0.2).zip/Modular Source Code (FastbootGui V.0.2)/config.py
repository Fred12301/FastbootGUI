#This file contains the configuration constants #and the logger settings.

import os
import sys
import logging

# --- Constantes de Configuration ---
IS_WINDOWS = os.name == "nt"
PLATFORM_TOOLS_URL = "https://dl.google.com/android/repository/platform-tools-latest-{}.zip"
DOWNLOAD_ZIP_NAME = "platform-tools.zip"
EXTRACT_DIR = "platform-tools"

# --- Configuration du Logger ---
log_filename = "adbinstaller.log"
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.StreamHandler(sys.stdout),
                        logging.FileHandler(log_filename, encoding="utf-8")
                    ])
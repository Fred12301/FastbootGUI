import os
import sys
import threading
import subprocess
import time
import ctypes
import logging
from datetime import datetime
from pathlib import Path
import shutil

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.progressbar import ProgressBar

from device_manager import DeviceManager
from config import IS_WINDOWS

class ADBInstaller(BoxLayout):
    def __init__(self, **kwargs):
        super(ADBInstaller, self).__init__(orientation='vertical', padding=10, spacing=10, **kwargs)
        # Définition de la langue par défaut en anglais
        self.language = "en"
        self.translations = {
            "en": {
                "check_adb_fastboot": "Check ADB/Fastboot",
                "install": "Install ADB/Fastboot",
                "update": "Update ADB/Fastboot",
                "cancel": "Cancel Operation",
                "export_log": "Export Log",
                "flash": "Flash",
                "browse": "Browse",
                "select_slot": "Select Slot",
                "select_partition": "Select Partition",
                "verbose_logging": "Verbose Logging",
                "force_install": "Force Install",
                "log_level": "Log Level",
                "reboot_recovery": "ADB Reboot Recovery",
                "reboot": "ADB Reboot",
                "reboot_bootloader": "ADB Reboot Bootloader",
                "reboot_edl": "Reboot EDL",
                "reboot_fastbootd": "Reboot FastbootD",
                "erase_cache": "Erase Cache",
                "check_adb_devices": "Check ADB Devices",
                "check_fastboot_devices": "Check Fastboot Devices",
                "check_lsusb": "Check LSUSB",
                "start_sideload": "Start Sideload",
                "getvar_all": "getvar all",
                "language": "Language: English",
                "install_linux": "Install via package manager",
                "update_linux": "Update via package manager",
                "no_device": "No device detected",
                "device_adb": "Device detected in ADB mode",
                "device_fastboot": "Device detected in Fastboot mode",
                "device_both": "Device detected in both ADB and Fastboot modes",
                "log_exported": "Log successfully exported to ",
                "warn_admin": "Warning: Run the script as Administrator for full functionality.",
                "warn_root": "Warning: Running without root privileges may cause issues with ADB/Fastboot."
            },
            "fr": {
                "check_adb_fastboot": "Vérifier ADB/Fastboot",
                "install": "Installer ADB/Fastboot",
                "update": "Mettre à jour ADB/Fastboot",
                "cancel": "Annuler l'opération",
                "export_log": "Exporter le Log",
                "flash": "Flasher",
                "browse": "Parcourir",
                "select_slot": "Sélectionner Slot",
                "select_partition": "Sélectionner Partition",
                "verbose_logging": "Log Verbose",
                "force_install": "Forcer l'installation",
                "log_level": "Niveau Log",
                "reboot_recovery": "ADB Reboot Recovery",
                "reboot": "ADB Reboot",
                "reboot_bootloader": "ADB Reboot Bootloader",
                "reboot_edl": "Reboot EDL",
                "reboot_fastbootd": "Reboot FastbootD",
                "erase_cache": "Effacer Cache",
                "check_adb_devices": "Vérifier périphériques ADB",
                "check_fastboot_devices": "Vérifier périphériques Fastboot",
                "check_lsusb": "Vérifier LSUSB",
                "start_sideload": "Démarrer Sideload",
                "getvar_all": "getvar all",
                "language": "Langue: Français",
                "install_linux": "Installation via gestionnaire de paquets",
                "update_linux": "Mise à jour via gestionnaire de paquets",
                "no_device": "Aucun appareil détecté",
                "device_adb": "Appareil détecté en mode ADB",
                "device_fastboot": "Appareil détecté en mode Fastboot",
                "device_both": "Appareil détecté en mode ADB et Fastboot",
                "log_exported": "Log exporté avec succès vers ",
                "warn_admin": "Attention : Exécutez le script en tant qu'administrateur pour une fonctionnalité complète.",
                "warn_root": "Attention : L'exécution sans privilèges root peut causer des problèmes avec ADB/Fastboot."
            }
        }

        # Initialisation du fichier sélectionné
        self.selected_file = None

        # Dictionnaire des widgets pour mise à jour dynamique de la langue
        self.widgets_to_update = {}

        # Zone de log interne
        self.log_text = ""
        self.cancel_flag = False

        self.log_view = TextInput(text='', readonly=True, size_hint_y=1,
                                  background_color=(0.12, 0.12, 0.12, 1),
                                  foreground_color=(0.9, 0.9, 0.9, 1),
                                  font_size='14sp', multiline=True)
        self.log_scroll = ScrollView(size_hint=(1, 0.35),
                                     do_scroll_x=False, do_scroll_y=True,
                                     bar_width=10)
        self.log_scroll.add_widget(self.log_view)
        self.add_widget(self.log_scroll)

        self.progress_bar = ProgressBar(max=100, value=0, size_hint_y=None, height=25)
        self.add_widget(self.progress_bar)

        # Vérification des privilèges
        if IS_WINDOWS:
            try:
                if not ctypes.windll.shell32.IsUserAnAdmin():
                    self.log_message(self.tr("warn_admin"), level="warning")
            except Exception as e:
                self.log_message(f"Error checking permissions: {e}", level="error")
        else:
            if os.geteuid() != 0:
                self.log_message(self.tr("warn_root"), level="warning")

        # Création du DeviceManager pour déléguer les opérations adb/fastboot
        self.device_manager = DeviceManager(self.log_message)

        # Panneau de contrôle principal (scrollable)
        self.control_panel = BoxLayout(orientation='vertical', size_hint_y=None, spacing=10)
        self.control_panel.bind(minimum_height=self.control_panel.setter('height'))

        # Boutons de base
        self.btn_check = Button(text=self.tr("check_adb_fastboot"), size_hint_y=None, height=40)
        self.btn_check.bind(on_press=self.on_check_pressed)
        self.control_panel.add_widget(self.btn_check)
        self.widgets_to_update["check"] = self.btn_check

        self.btn_install = Button(text=self.tr("install"), size_hint_y=None, height=40)
        self.btn_install.bind(on_press=self.on_install_pressed)
        self.control_panel.add_widget(self.btn_install)
        self.widgets_to_update["install"] = self.btn_install

        self.btn_update = Button(text=self.tr("update"), size_hint_y=None, height=40)
        self.btn_update.bind(on_press=self.on_update_pressed)
        self.control_panel.add_widget(self.btn_update)
        self.widgets_to_update["update"] = self.btn_update

        self.btn_cancel = Button(text=self.tr("cancel"), size_hint_y=None, height=40)
        self.btn_cancel.bind(on_press=self.on_cancel_pressed)
        self.control_panel.add_widget(self.btn_cancel)
        self.widgets_to_update["cancel"] = self.btn_cancel

        self.btn_export = Button(text=self.tr("export_log"), size_hint_y=None, height=40)
        self.btn_export.bind(on_press=self.export_log)
        self.control_panel.add_widget(self.btn_export)
        self.widgets_to_update["export_log"] = self.btn_export

        # Boutons Flash, Browse, Slot & Partition
        flash_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.btn_flash = Button(text=self.tr("flash"), size_hint_x=0.33, height=40)
        self.btn_flash.bind(on_press=self.on_flash_pressed)
        flash_layout.add_widget(self.btn_flash)
        self.widgets_to_update["flash"] = self.btn_flash

        self.btn_browse = Button(text=self.tr("browse"), size_hint_x=0.33, height=40)
        self.btn_browse.bind(on_press=self.on_browse_pressed)
        flash_layout.add_widget(self.btn_browse)
        self.widgets_to_update["browse"] = self.btn_browse

        self.slot_spinner = Spinner(
            text=self.tr("select_slot"),
            values=["None", "A", "B"],
            size_hint_x=0.33,
            height=40
        )
        flash_layout.add_widget(self.slot_spinner)
        self.control_panel.add_widget(flash_layout)
        self.widgets_to_update["select_slot"] = self.slot_spinner

        self.partition_spinner = Spinner(
            text=self.tr("select_partition"),
            values=["system", "boot", "recovery", "data",
                    "vendor", "vendor_kernel_boot", "vendor_boot",
                    "dtbo", "tee", "ramdisk", "bootloader"],
            size_hint_y=None, height=40
        )
        self.control_panel.add_widget(self.partition_spinner)
        self.widgets_to_update["select_partition"] = self.partition_spinner

        # Options : Verbose, Force et Log Level
        options_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.chk_verbose = CheckBox(active=False)
        options_layout.add_widget(self.chk_verbose)
        options_layout.add_widget(Label(text=self.tr("verbose_logging"), size_hint_x=0.4))

        self.chk_force = CheckBox(active=False)
        options_layout.add_widget(self.chk_force)
        options_layout.add_widget(Label(text=self.tr("force_install"), size_hint_x=0.4))
        
        self.log_level_spinner = Spinner(
            text="INFO",
            values=["DEBUG", "INFO", "WARNING", "ERROR"],
            size_hint_x=0.4,
            height=40
        )
        self.log_level_spinner.bind(text=self.on_log_level_change)
        options_layout.add_widget(Label(text=self.tr("log_level") + ":", size_hint_x=0.3))
        options_layout.add_widget(self.log_level_spinner)
        self.control_panel.add_widget(options_layout)

        # Boutons de reboot ADB
        reboot_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.btn_reboot_recovery = Button(text=self.tr("reboot_recovery"), size_hint_x=0.33, height=40)
        self.btn_reboot_recovery.bind(on_press=self.on_adb_reboot_recovery)
        reboot_layout.add_widget(self.btn_reboot_recovery)
        self.widgets_to_update["reboot_recovery"] = self.btn_reboot_recovery

        self.btn_reboot_bootloader = Button(text=self.tr("reboot_bootloader"), size_hint_x=0.33, height=40)
        self.btn_reboot_bootloader.bind(on_press=self.on_adb_reboot_bootloader)
        reboot_layout.add_widget(self.btn_reboot_bootloader)
        self.widgets_to_update["reboot_bootloader"] = self.btn_reboot_bootloader

        self.btn_reboot = Button(text=self.tr("reboot"), size_hint_x=0.33, height=40)
        self.btn_reboot.bind(on_press=self.on_adb_reboot)
        reboot_layout.add_widget(self.btn_reboot)
        self.widgets_to_update["reboot"] = self.btn_reboot
        self.control_panel.add_widget(reboot_layout)

        # Boutons de reboot Fastboot
        fastboot_reboot_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.btn_reboot_edl = Button(text=self.tr("reboot_edl"), size_hint_x=0.5, height=40)
        self.btn_reboot_edl.bind(on_press=self.on_reboot_edl_pressed)
        fastboot_reboot_layout.add_widget(self.btn_reboot_edl)
        self.widgets_to_update["reboot_edl"] = self.btn_reboot_edl

        self.btn_reboot_fastbootd = Button(text=self.tr("reboot_fastbootd"), size_hint_x=0.5, height=40)
        self.btn_reboot_fastbootd.bind(on_press=self.on_reboot_fastbootd_pressed)
        fastboot_reboot_layout.add_widget(self.btn_reboot_fastbootd)
        self.widgets_to_update["reboot_fastbootd"] = self.btn_reboot_fastbootd
        self.control_panel.add_widget(fastboot_reboot_layout)

        # Boutons de vérification d'appareils
        device_check_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.btn_check_adb = Button(text=self.tr("check_adb_devices"), size_hint_x=0.33, height=40)
        self.btn_check_adb.bind(on_press=lambda x: threading.Thread(target=self.device_manager.check_adb_devices, daemon=True).start())
        device_check_layout.add_widget(self.btn_check_adb)
        self.widgets_to_update["check_adb_devices"] = self.btn_check_adb

        self.btn_check_fastboot = Button(text=self.tr("check_fastboot_devices"), size_hint_x=0.33, height=40)
        self.btn_check_fastboot.bind(on_press=lambda x: threading.Thread(target=self.device_manager.check_fastboot_devices, daemon=True).start())
        device_check_layout.add_widget(self.btn_check_fastboot)
        self.widgets_to_update["check_fastboot_devices"] = self.btn_check_fastboot

        self.btn_check_lsusb = Button(text=self.tr("check_lsusb"), size_hint_x=0.33, height=40)
        self.btn_check_lsusb.bind(on_press=lambda x: threading.Thread(target=self.device_manager.check_lsusb, daemon=True).start())
        device_check_layout.add_widget(self.btn_check_lsusb)
        self.widgets_to_update["check_lsusb"] = self.btn_check_lsusb
        self.control_panel.add_widget(device_check_layout)

        # Sideload et getvar all
        sideload_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        if IS_WINDOWS:
            sideload_values = [".\\", "adb -b sideload", "adb -a sideload"]
        else:
            sideload_values = ["./", "adb -b sideload", "adb -a sideload"]
        self.sideload_spinner = Spinner(
            text=sideload_values[0],
            values=sideload_values,
            size_hint_x=0.5, height=40
        )
        sideload_layout.add_widget(self.sideload_spinner)
        self.btn_start_sideload = Button(text=self.tr("start_sideload"), size_hint_x=0.5, height=40)
        self.btn_start_sideload.bind(on_press=self.on_start_sideload_pressed)
        sideload_layout.add_widget(self.btn_start_sideload)
        self.widgets_to_update["start_sideload"] = self.btn_start_sideload
        self.control_panel.add_widget(sideload_layout)

        getvar_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.btn_getvar_all = Button(text=self.tr("getvar_all"), size_hint_x=1, height=40)
        self.btn_getvar_all.bind(on_press=self.on_getvar_all_pressed)
        getvar_layout.add_widget(self.btn_getvar_all)
        self.widgets_to_update["getvar_all"] = self.btn_getvar_all
        self.control_panel.add_widget(getvar_layout)

        # Bouton de basculement de langue
        self.btn_language = Button(text=self.tr("language"), size_hint_y=None, height=40)
        self.btn_language.bind(on_press=self.toggle_language)
        self.control_panel.add_widget(self.btn_language)
        self.widgets_to_update["language"] = self.btn_language

        # Placement du panneau de contrôle dans une zone scrollable
        self.control_scroll = ScrollView(size_hint=(1, 0.6))
        self.control_scroll.add_widget(self.control_panel)
        self.add_widget(self.control_scroll)

        # Étiquette d'état de détection automatique des appareils
        self.device_status_label = Label(text=self.tr("no_device"), size_hint_y=None, height=30)
        self.add_widget(self.device_status_label)
        Clock.schedule_interval(self.update_device_status, 5)

    def tr(self, key):
        """Retourne la traduction pour la clé donnée selon la langue actuelle."""
        return self.translations[self.language].get(key, key)

    def update_ui_language(self):
        """Actualise les textes de l'interface selon la langue sélectionnée."""
        for key, widget in self.widgets_to_update.items():
            if key in self.translations["en"]:
                widget.text = self.tr(key)
        self.device_status_label.text = self.tr("no_device")

    def log_message(self, message, level="info"):
        """Ajoute un message au log (console, fichier et interface)."""
        self.log_text += message + "\n"
        if level == "info":
            logging.info(message)
        elif level == "warning":
            logging.warning(message)
        elif level == "error":
            logging.error(message)
        Clock.schedule_once(lambda dt: self.append_to_log(message), 0)

    def append_to_log(self, message):
        """Met à jour la zone de log et fait défiler vers le bas."""
        self.log_view.text += message + "\n"
        Clock.schedule_once(lambda dt: setattr(self.log_scroll, 'scroll_y', 0), 0)

    def export_log(self, instance):
        """Exporte le contenu du log dans un fichier texte horodaté."""
        filename = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(self.log_text)
            self.log_message(self.tr("log_exported") + filename)
        except Exception as e:
            self.log_message(f"Error exporting log: {e}", level="error")

    def on_log_level_change(self, spinner, text):
        """Change dynamiquement le niveau de log."""
        level = getattr(logging, text.upper(), logging.INFO)
        logging.getLogger().setLevel(level)
        self.log_message(self.tr("log_level") + " set to " + text)

    def on_check_pressed(self, instance):
        threading.Thread(target=self.device_manager.check_adb_fastboot, daemon=True).start()

    def on_install_pressed(self, instance):
        threading.Thread(target=lambda: self.device_manager.install_adb_fastboot(
            progress_callback=lambda val: Clock.schedule_once(lambda dt: setattr(self.progress_bar, 'value', val), 0),
            cancel_flag_callback=lambda: self.cancel_flag
        ), daemon=True).start()

    def on_update_pressed(self, instance):
        threading.Thread(target=lambda: self.device_manager.update_adb_fastboot(
            progress_callback=lambda val: Clock.schedule_once(lambda dt: setattr(self.progress_bar, 'value', val), 0)
        ), daemon=True).start()

    def on_flash_pressed(self, instance):
        threading.Thread(target=self.flash_partition, daemon=True).start()

    def on_reboot_edl_pressed(self, instance):
        threading.Thread(target=self.device_manager.reboot_edl, daemon=True).start()

    def on_reboot_fastbootd_pressed(self, instance):
        threading.Thread(target=lambda: self.device_manager.reboot_command(["fastboot", "reboot", "fastboot"], "Reboot FastbootD"), daemon=True).start()

    def on_cancel_pressed(self, instance):
        """Annule toute opération longue en cours."""
        self.cancel_flag = True
        self.log_message("Cancel flag set. Ongoing operation will be cancelled.", level="warning")

    def on_adb_reboot_recovery(self, instance):
        threading.Thread(target=lambda: self.device_manager.reboot_command(["adb", "reboot", "recovery"], "ADB Reboot Recovery"), daemon=True).start()

    def on_adb_reboot_bootloader(self, instance):
        threading.Thread(target=lambda: self.device_manager.reboot_command(["adb", "reboot", "bootloader"], "ADB Reboot Bootloader"), daemon=True).start()

    def on_adb_reboot(self, instance):
        threading.Thread(target=lambda: self.device_manager.reboot_command(["adb", "reboot"], "ADB Reboot"), daemon=True).start()

    def toggle_language(self, instance):
        """Bascule entre anglais et français et met à jour l'interface en temps réel."""
        self.language = "fr" if self.language == "en" else "en"
        self.log_message("Language switched to " + self.translations[self.language]["language"])
        self.update_ui_language()

    def update_device_status(self, dt):
        """Vérifie en continu la connexion des appareils ADB et Fastboot et met à jour l'état."""
        try:
            adb_status = subprocess.run(["adb", "devices"], capture_output=True, text=True, timeout=5)
            fastboot_status = subprocess.run(["fastboot", "devices"], capture_output=True, text=True, timeout=5)
            adb_devices = [d for d in adb_status.stdout.strip().split("\n")[1:] if d.strip()]
            fastboot_devices = [d for d in fastboot_status.stdout.strip().split("\n") if d.strip()]
        except FileNotFoundError:
            adb_devices = []
            fastboot_devices = []
            self.log_message("ADB or Fastboot command not found.", level="error")
        except Exception as e:
            self.log_message("Error checking device status: " + str(e), level="error")
            adb_devices = []
            fastboot_devices = []
        if adb_devices and fastboot_devices:
            status = self.tr("device_both")
        elif adb_devices:
            status = self.tr("device_adb")
        elif fastboot_devices:
            status = self.tr("device_fastboot")
        else:
            status = self.tr("no_device")
        self.device_status_label.text = status

    def flash_partition(self):
        """
        Vérifie la connexion en fastboot et flash la partition sélectionnée après confirmation.
        Prend en compte les options verbose et force.
        """
        try:
            result = subprocess.run(["fastboot", "devices"], capture_output=True, text=True, timeout=10)
        except Exception as e:
            self.log_message("Error running 'fastboot devices': " + str(e), level="error")
            return

        if not result.stdout.strip():
            self.log_message("Error: No device detected in fastboot mode. Connect your phone and try again.", level="error")
            return

        partition = self.partition_spinner.text
        slot = self.slot_spinner.text
        file_to_flash = self.selected_file

        if not file_to_flash or not Path(file_to_flash).exists():
            self.log_message("Error: No file selected for flashing or file does not exist.", level="error")
            return

        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text=f"Flash file:\n{file_to_flash}\non partition: {partition} (Slot: {slot}) ?"))
        btn_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        btn_yes = Button(text="Yes", size_hint_y=None, height=40)
        btn_no = Button(text="No", size_hint_y=None, height=40)
        btn_layout.add_widget(btn_yes)
        btn_layout.add_widget(btn_no)
        content.add_widget(btn_layout)
        popup = Popup(title="Confirm Flash", content=content, size_hint=(0.8, 0.5))

        def confirmed(instance):
            popup.dismiss()
            self.log_message("Preparing to flash...")
            try:
                self.log_message("Flashing in progress...")
                # Décommentez la ligne suivante pour réaliser le flash effectif :
                # subprocess.run(["fastboot", "flash", partition, file_to_flash], check=True)
                time.sleep(2)  # Simulation de délai
                if self.chk_verbose.active:
                    self.log_message("Verbose mode: Detailed flash log output...")
                if self.chk_force.active:
                    self.log_message("Force Install enabled: Safety checks bypassed.")
                self.log_message("Flash completed successfully.")
            except Exception as e:
                self.log_message("Error during flash: " + str(e), level="error")

        def cancelled(instance):
            self.log_message("Flash cancelled by user.", level="warning")
            popup.dismiss()

        btn_yes.bind(on_press=confirmed)
        btn_no.bind(on_press=cancelled)
        popup.open()

    def on_browse_pressed(self, instance):
        """Ouvre un sélecteur de fichiers pour choisir un fichier flashable et ajuste les partitions."""
        filechooser = FileChooserListView(path=os.getcwd())

        def select_file(instance):
            if filechooser.selection:
                selected = filechooser.selection[0]
                allowed = ('.img', '.tar', '.tar.md5', '.zip')
                if selected.lower().endswith(allowed):
                    self.selected_file = selected
                    self.log_message("Selected file: " + selected)
                    if ".boot" in selected:
                        self.partition_spinner.values = ["boot", "vendor_boot", "dtbo"]
                    elif ".recovery" in selected:
                        self.partition_spinner.values = ["recovery"]
                    elif ".system" in selected:
                        self.partition_spinner.values = ["system", "system_ext", "vendor"]
                    else:
                        self.partition_spinner.values = ["system", "boot", "recovery", "data",
                                                         "vendor", "vendor_kernel_boot", "vendor_boot",
                                                         "dtbo", "tee", "ramdisk", "bootloader"]
                    self.partition_spinner.text = self.partition_spinner.values[0]
                else:
                    self.log_message("Error: Selected file does not have an allowed extension.", level="error")
            else:
                self.log_message("No file selected.", level="warning")
            popup.dismiss()

        popup_layout = BoxLayout(orientation='vertical')
        popup_layout.add_widget(filechooser)
        btn_select = Button(text="Select", size_hint_y=None, height=40)
        btn_select.bind(on_press=select_file)
        popup_layout.add_widget(btn_select)
        popup = Popup(title="Browse Files", content=popup_layout, size_hint=(0.9, 0.9))
        popup.open()

    def on_start_sideload_pressed(self, instance):
        """Démarre la commande sideload en fonction du mode sélectionné."""
        if not self.selected_file:
            self.log_message("Error: No file selected for sideload.", level="error")
            return

        mode = self.sideload_spinner.text
        if mode in [".\\", "./"]:
            args = ["adb", "sideload"]
        elif mode == "adb -b sideload":
            args = ["adb", "-b", "sideload"]
        elif mode == "adb -a sideload":
            args = ["adb", "-a", "sideload"]
        else:
            self.log_message("Error: Unrecognized sideload mode.", level="error")
            return

        filename = Path(self.selected_file).name
        file_arg = f".\\{filename}" if IS_WINDOWS else f"./{filename}"
        args.append(file_arg)
        self.log_message("Starting sideload command: " + " ".join(args))

        def run_sideload():
            try:
                result = subprocess.run(args, capture_output=True, text=True, timeout=60)
                if result.returncode == 0:
                    self.log_message("Sideload completed successfully.")
                else:
                    self.log_message("Error during sideload (code " + str(result.returncode) + "): " + result.stderr, level="error")
            except Exception as e:
                self.log_message("Exception during sideload: " + str(e), level="error")
        threading.Thread(target=run_sideload, daemon=True).start()

    def on_getvar_all_pressed(self, instance):
        """Exécute la commande 'fastboot getvar all' et affiche le résultat."""
        self.log_message("Executing 'fastboot getvar all' command...")
        threading.Thread(target=self.device_manager.run_getvar_all, daemon=True).start()

class ADBInstallerApp(App):
    def build(self):
        return ADBInstaller()
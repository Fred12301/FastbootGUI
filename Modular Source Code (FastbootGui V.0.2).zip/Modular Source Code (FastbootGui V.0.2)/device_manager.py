#This module includes the DeviceManager class, #which centralizes all ADB/Fastboot operations #(installation, update, reboot, checks, etc.). It #imports the previously defined utilities and #constants.

import subprocess
import shutil
import os
import logging
import time
from pathlib import Path

from utils import calculate_file_hash, download_file, extract_zip, tool_available, tool_in_path
from config import IS_WINDOWS, PLATFORM_TOOLS_URL, DOWNLOAD_ZIP_NAME, EXTRACT_DIR

class DeviceManager:
    def __init__(self, logger):
        """
        Le logger est une fonction de rappel (callback) pour afficher des messages.
        """
        self.logger = logger

    def check_adb_fastboot(self):
        self.logger("Starting check for ADB and Fastboot...")
        adb_installed = tool_available("adb")
        fastboot_installed = tool_available("fastboot")

        if not tool_in_path("adb"):
            self.logger("Warning: ADB is not in the PATH. Please add 'platform-tools' to your PATH.", level="warning")
        if not tool_in_path("fastboot"):
            self.logger("Warning: Fastboot is not in the PATH.", level="warning")

        if not IS_WINDOWS:
            if shutil.which("apt") or shutil.which("dnf") or shutil.which("pacman") or shutil.which("zypper"):
                self.logger("Linux package manager detected.")
            else:
                self.logger("No known package manager detected on Linux.", level="warning")

        if adb_installed and fastboot_installed:
            self.logger("ADB and Fastboot are installed and operational.")
        else:
            missing = []
            if not adb_installed:
                missing.append("ADB")
            if not fastboot_installed:
                missing.append("Fastboot")
            self.logger("Error: Missing dependency(ies): " + ", ".join(missing) + ".", level="error")
            self.logger("Please click 'Install' to install the required dependencies.", level="warning")

    def install_adb_fastboot(self, progress_callback=None, cancel_flag_callback=lambda: False):
        self.logger("Starting ADB/Fastboot installation...")
        if IS_WINDOWS:
            os_name = "windows"
            url = PLATFORM_TOOLS_URL.format(os_name)
            self.logger("Downloading from " + url + " ...")
            if download_file(url, DOWNLOAD_ZIP_NAME, progress_callback=progress_callback, cancel_check=cancel_flag_callback):
                self.logger("Download completed. Validating file...")
                from zipfile import is_zipfile
                if not is_zipfile(DOWNLOAD_ZIP_NAME):
                    self.logger("Error: Downloaded file is not a valid zip.", level="error")
                    return
                file_hash = calculate_file_hash(DOWNLOAD_ZIP_NAME)
                self.logger("Downloaded file hash: " + str(file_hash))
                self.logger("File validated. Extracting...")
                if extract_zip(DOWNLOAD_ZIP_NAME, EXTRACT_DIR, progress_callback=progress_callback):
                    adb_filename = "adb.exe" if IS_WINDOWS else "adb"
                    adb_path = Path(EXTRACT_DIR) / adb_filename
                    if adb_path.exists():
                        self.logger("Installation successful! Add 'platform-tools' to your PATH.")
                    else:
                        self.logger("Error: Installation failed. 'platform-tools' not found after extraction.", level="error")
                else:
                    self.logger("Error during extraction.", level="error")
            else:
                self.logger("Error during download or download cancelled.", level="error")
        else:
            self.logger("Installing via package manager...", level="info")
            if shutil.which("apt"):
                cmd = ["sudo", "apt", "install", "-y", "android-tools-adb", "android-tools-fastboot"]
            elif shutil.which("dnf"):
                cmd = ["sudo", "dnf", "install", "-y", "android-tools"]
            elif shutil.which("pacman"):
                cmd = ["sudo", "pacman", "-S", "--noconfirm", "android-tools"]
            elif shutil.which("zypper"):
                cmd = ["sudo", "zypper", "install", "-y", "android-tools"]
            else:
                self.logger("No supported package manager found.", level="error")
                return
            self.logger("Running command: " + " ".join(cmd))
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                if result.returncode == 0:
                    self.logger("Installation completed successfully via package manager.")
                else:
                    self.logger("Error during package installation: " + result.stderr, level="error")
            except Exception as e:
                self.logger("Exception during package installation: " + str(e), level="error")

    def update_adb_fastboot(self, progress_callback=None):
        self.logger("Starting update for ADB/Fastboot...")
        if IS_WINDOWS:
            if Path(EXTRACT_DIR).exists():
                try:
                    shutil.rmtree(EXTRACT_DIR)
                    self.logger("Previous platform-tools removed successfully.")
                except Exception as e:
                    self.logger("Error removing old platform-tools: " + str(e), level="error")
                    return
            self.install_adb_fastboot(progress_callback=progress_callback)
        else:
            self.logger("Updating via package manager...", level="info")
            if shutil.which("apt"):
                cmd = ["sudo", "apt", "upgrade", "-y", "android-tools-adb", "android-tools-fastboot"]
            elif shutil.which("dnf"):
                cmd = ["sudo", "dnf", "update", "-y", "android-tools"]
            elif shutil.which("pacman"):
                cmd = ["sudo", "pacman", "-Syu", "--noconfirm", "android-tools"]
            elif shutil.which("zypper"):
                cmd = ["sudo", "zypper", "update", "-y", "android-tools"]
            else:
                self.logger("No supported package manager found.", level="error")
                return
            self.logger("Running update command: " + " ".join(cmd))
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                if result.returncode == 0:
                    self.logger("Update completed successfully via package manager.")
                else:
                    self.logger("Error during package update: " + result.stderr, level="error")
            except Exception as e:
                self.logger("Exception during package update: " + str(e), level="error")

    def check_fastboot_mode(self):
        try:
            result = subprocess.run(["fastboot", "getvar", "is-userspace"], capture_output=True, text=True, timeout=10)
            if "is-userspace: yes" in result.stdout:
                self.logger("Device is in fastbootd mode.")
                return True
            else:
                self.logger("Device is in classic fastboot mode.")
                return False
        except Exception as e:
            self.logger("Error detecting fastboot mode: " + str(e), level="error")
            return False

    def reboot_command(self, command, description):
        try:
            self.logger(description + ": " + " ".join(command))
            result = subprocess.run(command, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                self.logger(description + " executed successfully.")
            else:
                self.logger("Error: " + description + " returned code " + str(result.returncode) + ".", level="error")
        except Exception as e:
            self.logger("Exception executing " + description + ": " + str(e), level="error")

    def reboot_edl(self):
        try:
            self.logger("Attempting to reboot device into EDL mode...")
            result = subprocess.run(["fastboot", "reboot", "edl"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                self.logger("EDL reboot command executed successfully.")
            else:
                self.logger("Error: EDL reboot returned code " + str(result.returncode), level="error")
        except Exception as e:
            self.logger("Exception during EDL reboot: " + str(e), level="error")

    def check_adb_devices(self):
        try:
            result = subprocess.run(["adb", "devices"], capture_output=True, text=True, timeout=10)
            devices = result.stdout.strip().split("\n")[1:]
            if devices and any(dev.strip() for dev in devices):
                self.logger("Connected ADB devices:")
                for device in devices:
                    if device.strip():
                        self.logger("- " + device)
            else:
                self.logger("No ADB device detected.")
        except Exception as e:
            self.logger("Error checking ADB devices: " + str(e), level="error")

    def check_fastboot_devices(self):
        try:
            result = subprocess.run(["fastboot", "devices"], capture_output=True, text=True, timeout=10)
            devices = result.stdout.strip().split("\n")
            if devices and any(dev.strip() for dev in devices):
                self.logger("Connected Fastboot devices:")
                for device in devices:
                    if device.strip():
                        self.logger("- " + device)
            else:
                self.logger("No Fastboot device detected.")
        except Exception as e:
            self.logger("Error checking Fastboot devices: " + str(e), level="error")

    def check_lsusb(self):
        if IS_WINDOWS:
            self.logger("LSUSB is not available on Windows.")
            return

        lsusb_path = shutil.which("lsusb")
        if not lsusb_path:
            self.logger("lsusb command not found. Attempting to install usbutils...", level="warning")
            if os.geteuid() == 0:
                try:
                    subprocess.run(["apt-get", "update"], check=True)
                    subprocess.run(["apt-get", "install", "-y", "usbutils"], check=True)
                    self.logger("usbutils installed successfully.")
                except Exception as e:
                    self.logger("Error installing usbutils: " + str(e), level="error")
                    return
            else:
                self.logger("Please run the script as root to install usbutils.", level="warning")
                return

        try:
            result = subprocess.run(["lsusb"], capture_output=True, text=True, timeout=10)
            self.logger("LSUSB output:")
            self.logger(result.stdout)
        except Exception as e:
            self.logger("Error running lsusb: " + str(e), level="error")

    def run_getvar_all(self):
        self.logger("Executing 'fastboot getvar all' command...")
        try:
            result = subprocess.run(["fastboot", "getvar", "all"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                self.logger("Output of 'fastboot getvar all':")
                self.logger(result.stdout)
            else:
                self.logger("Error: 'fastboot getvar all' returned code " + str(result.returncode) + ".", level="error")
            # Remarque : en cas d'erreur, le message est loggé.
        except Exception as e:
            self.logger("Exception during 'fastboot getvar all': " + str(e), level="error")
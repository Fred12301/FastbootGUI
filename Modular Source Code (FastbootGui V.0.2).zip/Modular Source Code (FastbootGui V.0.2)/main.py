from ui import ADBInstallerApp

if __name__ == "__main__":
    ADBInstallerApp().run()
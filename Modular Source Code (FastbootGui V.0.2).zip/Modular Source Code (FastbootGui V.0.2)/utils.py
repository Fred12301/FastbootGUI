#This module contains all utility functions (hash #calculation, downloading, extraction, tool #presence verification, etc.).

import os
import hashlib
import urllib.request
from zipfile import ZipFile, is_zipfile
import logging
import shutil
from pathlib import Path

def calculate_file_hash(file_path, algorithm="sha256"):
    """Calcule l'empreinte du fichier pour vérification d'intégrité."""
    hash_func = hashlib.new(algorithm)
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_func.update(chunk)
        return hash_func.hexdigest()
    except Exception as e:
        logging.error("Error calculating hash: %s", e)
        return None

def download_file(url, destination, progress_callback=None, cancel_check=lambda: False):
    """
    Télécharge un fichier depuis l'URL donnée vers la destination.
    Supporte la reprise du téléchargement si un fichier partiel existe.
    """
    dest_path = Path(destination)
    try:
        resume_byte_pos = dest_path.stat().st_size if dest_path.exists() else 0

        req = urllib.request.Request(url)
        if resume_byte_pos:
            req.add_header("Range", f"bytes={resume_byte_pos}-")
            logging.info("Resuming download at byte %s", resume_byte_pos)

        with urllib.request.urlopen(req) as response, open(destination, "ab") as out_file:
            total_length = response.getheader("content-length")
            if total_length:
                total_length = int(total_length) + resume_byte_pos
            downloaded = resume_byte_pos
            block_size = 8192
            while True:
                if cancel_check():
                    logging.warning("Download cancelled by user.")
                    return False
                block = response.read(block_size)
                if not block:
                    break
                out_file.write(block)
                downloaded += len(block)
                if progress_callback and total_length:
                    progress_callback(downloaded / total_length * 100)
        return True
    except Exception as e:
        logging.error("Download error: %s", e)
        return False

def extract_zip(zip_path, extract_to, progress_callback=None):
    """
    Extrait le fichier zip dans le répertoire spécifié.
    """
    try:
        if not is_zipfile(zip_path):
            raise Exception("Invalid file (not a zip)")
        with ZipFile(zip_path, "r") as zip_ref:
            file_list = zip_ref.namelist()
            total_files = len(file_list)
            for i, file in enumerate(file_list, 1):
                zip_ref.extract(file, extract_to)
                if progress_callback:
                    progress_callback(i / total_files * 100)
        return True
    except Exception as e:
        logging.error("Extraction error: %s", e)
        return False

def tool_available(tool):
    """
    Vérifie si un outil est disponible en lançant 'tool version' ou 'tool --version'.
    """
    import subprocess
    try:
        for arg in ["version", "--version"]:
            try:
                result = subprocess.run([tool, arg], capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    logging.info("%s detected: %s", tool, result.stdout.splitlines()[0])
                    return True
            except Exception:
                continue
        logging.warning("%s did not return a version.", tool)
        return False
    except Exception as e:
        logging.error("Error checking %s: %s", tool, e)
        return False

def tool_in_path(tool):
    """Vérifie si l'outil est présent dans le PATH."""
    return any(Path(path, tool).exists() for path in os.environ["PATH"].split(os.pathsep))